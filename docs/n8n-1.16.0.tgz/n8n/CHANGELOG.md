# Changelog

This file documents all notable changes to the [n8n-helm-chart](https://github.com/maximilianoPizarro/n8n-helm-chart/). The release numbering uses [semantic versioning](http://semver.org).

The full changelog is located in GitHub release notes https://github.com/maximilianoPizarro/n8n-helm-chart/releases/ and as summery on https://artifacthub.io/packages/helm/open-8gears/n8n?modal=changelog
