# Changelog

This file documents all notable changes to the [n8n-helm-chart](https://github.com/maximilianoPizarro/n8n-helm-chart/). The release numbering uses [semantic versioning](http://semver.org).

Also see GitHub Releases: https://github.com/maximilianoPizarro/n8n-helm-chart/releases

## [1.19.0] — 2026-10-31

### Highlights

- Upgrade n8n from **2.36.7** to **2.45.7** (latest stable)
- Chart **1.18.0** / **1.17.1** / **1.16.0** remain available for existing catalog RC installs

### Fixed

- Behind OpenShift Route / Ingress, inject `N8N_PROXY_HOPS=1` (unless overridden) so express-rate-limit accepts `X-Forwarded-For` / `Forwarded` and stops logging `ERR_ERL_UNEXPECTED_X_FORWARDED_FOR`

### Changed

- UBI image / CI default target n8n **2.45.7** (`container/Containerfile` on Node.js 24)
- Workflow auto-import still uses `workflows.autoImport.urls` (initContainers); no ConfigMap path change
- `values-sandbox.yaml` sets `N8N_PROXY_HOPS: "1"` explicitly

```shell
helm upgrade n8n n8n-openshift/n8n --version 1.19.0 -f values-sandbox.yaml
```

## [1.18.0] — 2026-08-25

### Highlights

- Upgrade n8n from **2.32.7** to **2.36.7** (latest stable)
- Fix catalog/Sandbox CrashLoop: `EACCES mkdir '/home/node/.cache'`

### Fixed

- Set `HOME`, `N8N_USER_FOLDER`, and `XDG_CACHE_HOME` to the writable `main.persistence.mountPath` (no longer strip `/.n8n`, which left `HOME=/home/node` unwritable under OpenShift random UIDs)
- Default `route.sccRoleDisabled: true` for Developer Sandbox-friendly installs from the catalog

### Changed

- UBI image / CI default target n8n **2.36.7**
- Chart **1.17.1** / **1.16.0** remain available for existing catalog RC installs
- Documented AI Assistant on Developer Sandbox: Model (LiteLLM/Qwen) + Web search (SearXNG); Code sandbox requires Daytona (privileged n8n Sandbox not available)

```shell
helm upgrade n8n n8n-openshift/n8n --version 1.18.0 -f values-sandbox.yaml
```

## [1.17.1] — 2026-08-01


### Fixed

- `values.schema.json`: allow `worker.enabled`, `webhook.enabled`, and `main.persistence.type`
- Dynamic PVC path: honor `persistence.type` / `existingClaim` and use `accessMode` when `accessModes` is unset
- Wire `startupProbe` on main, worker, and webhook Deployments

### Changed

- Main probes tuned for OpenShift cold starts (`startupProbe` ~3 min budget; longer liveness/readiness timeouts)
- Consolidate Sandbox overlay to a single [`values-sandbox.yaml`](values-sandbox.yaml)

```shell
helm upgrade n8n n8n-openshift/n8n --version 1.17.1 -f values-sandbox.yaml
```

## [1.17.0] — 2026-08-01

### Highlights

- Upgrade n8n from **1.123.28** to **2.32.7** (latest stable)
- Rebuild UBI image: `quay.io/maximilianopizarro/n8n:2.32.7`
- Fix OpenShift `EACCES: permission denied, mkdir '/.n8n'`
- Keep chart **1.16.0** in the Helm repository for existing catalog RC installs

### Fixed

- Always inject `HOME` and `N8N_USER_FOLDER` in the main Deployment (and import initContainer) from `main.persistence.mountPath`, so random UIDs with `HOME=/` no longer crash n8n

### Changed

- `container/Containerfile` targets n8n 2.32.7 and locates `sqlite3` dynamically under pnpm
- Documentation: Sandbox install via [`values-sandbox.yaml`](values-sandbox.yaml), EACCES notes, 1.x → 2.x upgrade guide
- Artifact Hub changelog clarified: workflow auto-import uses Deployment **initContainers** (not a Helm post-install Job)

### Upgrade notes (1.16.0 → 1.17.0)

1. Backup the n8n database before upgrading (2.x migrations).
2. Keep `NODE_FUNCTION_ALLOW_BUILTIN: "*"` for MCP Code nodes on n8n 2.x.
3. Prefer `main.persistence.mountPath: "/data"` on OpenShift; do not duplicate `HOME` / `N8N_USER_FOLDER` in `extraEnvVars`.
4. First start may take longer; wait for Ready if a single liveness restart occurs during migrations.

```shell
helm repo update
helm upgrade n8n n8n-openshift/n8n --version 1.17.1 -f values-sandbox.yaml
```

To stay on n8n 1.123.28:

```shell
helm upgrade n8n n8n-openshift/n8n --version 1.16.0
```

## [1.16.0] — 2026-04-06

### Added

- 7 OpenShift MCP Server workflows (Streamable HTTP + session handling) with AI Format & Explain (LiteLLM/Granite) and Mailpit HTML reports
- Workflow auto-import via Deployment initContainers
- Optional Mailpit SMTP test service with OpenShift Route
- `enableServiceLinks` and `route.sccRoleDisabled` for Developer Sandbox
- Red Hat UBI image at `quay.io/maximilianopizarro/n8n` (CI build)
- `image.variant` (`official` / `ubi`) to select `wget` vs `curl` for workflow downloads
- Configurable `main.persistence.mountPath`
- Chart Verifier GitHub Actions workflow

### Changed

- n8n app version **1.123.28**
- GitHub Pages documentation redesign (MCP pipeline, lightbox, Mermaid)

### Fixed

- `ClusterIP_` typo in service template
- Hardcoded names in `role.yaml` replaced with chart naming helpers
